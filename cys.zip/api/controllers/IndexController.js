/**
 * IndexController
 *
 * @description :: Server-side logic for managing indices
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

var Crawler = require("crawler");
var dateFormat = require('dateformat');

module.exports = {

    /**
     * `IndexController.index()`
     */
    index: function (req, res) {

        var c = new Crawler({
            maxConnections: 10,
            // This will be called for each crawled page
            callback: function (error, doc, done) {
                if (error) {
                    res.view('homepage', {'error': error});
                } else {
                    var $ = doc.$;
                    var links = [];
                    $(".matsh_live").each(function (i, elem) {
                        links[i] = {
                            "link": $(elem).attr('href'),
                            "time": $(elem).find('.fc_time').text(),
                            "team1": $(elem).find('li').find('.fc_name').first().text(),
                            "team2": $(elem).find('li').find('.fc_name').last().text(),
                            "logo1": $(elem).find('li').find('img').first().attr('src')
                                .replace('..', 'http://www.yalla-shoot.com'),
                            "logo2": $(elem).find('li').find('img').last().attr('src')
                                .replace('..', 'http://www.yalla-shoot.com'),
                            "text": []
                        };

                        $(elem).find('li').find('table').last().find('td').each(function (index) {
                            links[i]["text"][index] = $(this).find('p').html();
                        })
                    });

                    res.view('index', {links: links, now: dateFormat(new Date(), "dd-mm-yyyy")});
                }
                done();
            }
        });

        c.queue('http://www.yalla-shoot.com/live/index.php');
    },

    /**
     * `IndexController.index()`
     */
    detail: function (req, res) {

        var c = new Crawler({
            maxConnections: 10,
            // This will be called for each crawled page
            callback: function (error, doc, done) {
                if (error) {
                    res.view('homepage', {'error': error});
                } else {
                    var $ = doc.$;
                    var list = $(".live_box_pop").html();
                    var js = $(".live_box_pop").next().html()
                        .replace('.tooltip();', '');

                    res.view('detail', {'list': list, 'js': js});
                }
                done();
            }
        });

        c.queue('http://www.yalla-shoot.com/live/' + req.param('url'));
    }
};
